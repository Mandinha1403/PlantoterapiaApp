package com.example.plantoterapiaapp;

import android.graphics.Bitmap;

public class MyItem {
    public String title;
    public Bitmap photo;
    public String description;

}
