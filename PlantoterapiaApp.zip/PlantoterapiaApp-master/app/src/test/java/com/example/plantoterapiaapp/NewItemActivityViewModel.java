package com.example.plantoterapiaapp;

public class NewItemActivityViewModel {
}
